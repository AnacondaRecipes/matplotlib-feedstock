********************
``matplotlib.table``
********************

.. automodule:: matplotlib.table
   :members:
   :undoc-members:
   :show-inheritance:
