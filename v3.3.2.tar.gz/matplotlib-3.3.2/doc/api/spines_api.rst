*********************
``matplotlib.spines``
*********************

.. automodule:: matplotlib.spines
   :members:
   :undoc-members:
   :show-inheritance:
