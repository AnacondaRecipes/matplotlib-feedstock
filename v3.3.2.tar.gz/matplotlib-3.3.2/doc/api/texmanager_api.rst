*************************
``matplotlib.texmanager``
*************************

.. automodule:: matplotlib.texmanager
   :members:
   :undoc-members:
   :show-inheritance:
